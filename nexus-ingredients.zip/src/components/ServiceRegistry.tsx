import React, { useState, useEffect, useCallback } from 'react';
import { Cpu, Globe, Shield, Terminal, Zap, Activity, RefreshCw, HeartPulse, AlertCircle, CheckCircle2, ChevronDown, ChevronUp, Clock } from 'lucide-react';
import { services as initialServices, ServiceNode } from '../lib/mockData';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';

type ExtendedServiceNode = ServiceNode & { 
  lastChecked: string; 
  lastSuccess: string;
  errorMessage?: string;
};

export const ServiceRegistry: React.FC = () => {
  const [localServices, setLocalServices] = useState<ExtendedServiceNode[]>(
    initialServices.map(s => ({ 
      ...s, 
      lastChecked: new Date().toISOString(),
      lastSuccess: new Date().toISOString()
    }))
  );
  const [isChecking, setIsChecking] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const performHealthCheck = useCallback(() => {
    setIsChecking(true);
    
    const errorMessages = [
      "Connection timeout on port 443",
      "Memory pressure exceeding 90% threshold",
      "Upstream dependency 'Auth-Gateway' unreachable",
      "Database connection pool exhausted",
      "SSL certificate validation failed",
      "High disk I/O wait detected"
    ];

    setTimeout(() => {
      setLocalServices(prev => prev.map(svc => {
        const rand = Math.random();
        let newStatus = svc.status;
        let newLatency = svc.latency;
        let errorMessage = undefined;
        let lastSuccess = svc.lastSuccess;

        if (rand > 0.85) {
          newStatus = 'Degraded';
          newLatency = Math.floor(Math.random() * 500) + 300;
          errorMessage = errorMessages[Math.floor(Math.random() * errorMessages.length)];
        } else if (rand > 0.97) {
          newStatus = 'Down';
          newLatency = 0;
          errorMessage = "Service process terminated unexpectedly (SIGKILL)";
        } else {
          newStatus = 'Healthy';
          newLatency = Math.floor(Math.random() * 50) + 5;
          lastSuccess = new Date().toISOString();
        }

        return {
          ...svc,
          status: newStatus,
          latency: newLatency,
          lastChecked: new Date().toISOString(),
          lastSuccess,
          errorMessage
        };
      }));
      setIsChecking(false);
    }, 800);
  }, []);

  useEffect(() => {
    const interval = setInterval(performHealthCheck, 5000);
    return () => clearInterval(interval);
  }, [performHealthCheck]);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-6 pb-12">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold">Service Registry</h2>
          <p className="text-zinc-500 text-sm">Polyglot microservices mesh status and health.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={performHealthCheck}
            disabled={isChecking}
            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-xs font-mono text-zinc-300 hover:bg-zinc-800 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={cn("w-3.5 h-3.5", isChecking && "animate-spin")} />
            Manual Check
          </button>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg">
            <Globe className="w-4 h-4 text-zinc-500" />
            <span className="text-xs font-mono text-zinc-300">Cluster: nexus-prod-01</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 items-start">
        {localServices.map((svc, i) => (
          <motion.div 
            layout
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
            key={svc.id} 
            onClick={() => toggleExpand(svc.id)}
            className={cn(
              "p-5 bg-zinc-900 border rounded-2xl transition-all group relative overflow-hidden cursor-pointer",
              expandedId === svc.id ? "border-blue-500/50 ring-1 ring-blue-500/20" : "border-zinc-800 hover:border-zinc-700"
            )}
          >
            {/* Background Glow */}
            <div className={cn(
              "absolute -right-4 -top-4 w-24 h-24 blur-3xl opacity-10 transition-all duration-500 group-hover:opacity-20",
              svc.status === 'Healthy' ? "bg-green-500" : svc.status === 'Degraded' ? "bg-amber-500" : "bg-red-500"
            )} />

            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "p-2 rounded-lg transition-colors duration-500",
                  svc.status === 'Healthy' ? "bg-green-500/10 text-green-400" : 
                  svc.status === 'Degraded' ? "bg-amber-500/10 text-amber-400" : 
                  "bg-red-500/10 text-red-400"
                )}>
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-zinc-100">{svc.name}</h4>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-zinc-500 uppercase">{svc.id}</span>
                    <span className="w-1 h-1 bg-zinc-700 rounded-full" />
                    <span className="text-[10px] font-bold text-blue-500 uppercase tracking-wider">{svc.language}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1">
                <div className={cn(
                  "px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-widest transition-colors duration-500",
                  svc.status === 'Healthy' ? "bg-green-500/20 text-green-400" : 
                  svc.status === 'Degraded' ? "bg-amber-500/20 text-amber-400" : 
                  "bg-red-500/20 text-red-400"
                )}>
                  {svc.status}
                </div>
                <div className="flex items-center gap-1 text-[8px] text-zinc-600 font-mono">
                  <HeartPulse className={cn("w-2.5 h-2.5", svc.status === 'Healthy' && "animate-pulse")} />
                  {new Date(svc.lastChecked).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="space-y-1">
                <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-wider">Latency</div>
                <div className="text-sm font-mono text-zinc-300 flex items-center gap-1">
                  <Zap className={cn("w-3 h-3", svc.latency > 300 ? "text-red-500" : "text-amber-500")} />
                  {svc.latency}ms
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-wider">Uptime</div>
                <div className="text-sm font-mono text-zinc-300 flex items-center gap-1">
                  <Shield className="w-3 h-3 text-blue-500" />
                  {svc.uptime}
                </div>
              </div>
              <div className="space-y-1">
                <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-wider">Load</div>
                <div className="text-sm font-mono text-zinc-300 flex items-center gap-1">
                  <Activity className="w-3 h-3 text-purple-500" />
                  {svc.status === 'Down' ? '0%' : '12%'}
                </div>
              </div>
            </div>

            <AnimatePresence>
              {expandedId === svc.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <div className="pt-4 mt-4 border-t border-zinc-800 space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1">
                        <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-wider">Last Success</div>
                        <div className="text-xs font-mono text-zinc-400 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3 h-3 text-green-500" />
                          {new Date(svc.lastSuccess).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-wider">Response Time</div>
                        <div className="text-xs font-mono text-zinc-400 flex items-center gap-1.5">
                          <Clock className="w-3 h-3 text-blue-500" />
                          {svc.latency}ms (avg: {svc.latency - 2}ms)
                        </div>
                      </div>
                    </div>

                    {svc.errorMessage && (
                      <div className="p-3 bg-red-500/5 border border-red-500/10 rounded-lg">
                        <div className="flex items-center gap-2 text-[9px] font-bold text-red-500 uppercase tracking-wider mb-1">
                          <AlertCircle className="w-3 h-3" />
                          Error Details
                        </div>
                        <p className="text-xs text-red-400/80 font-mono leading-relaxed">
                          {svc.errorMessage}
                        </p>
                      </div>
                    )}

                    <div className="flex gap-2">
                      <button className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-bold uppercase tracking-widest rounded transition-colors flex items-center justify-center gap-2">
                        <Terminal className="w-3 h-3" />
                        Logs
                      </button>
                      <button className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-bold uppercase tracking-widest rounded transition-colors">
                        Metrics
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="mt-4 flex justify-center text-zinc-600 group-hover:text-zinc-400 transition-colors">
              {expandedId === svc.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
