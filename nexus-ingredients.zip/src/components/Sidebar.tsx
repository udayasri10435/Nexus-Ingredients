import React from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Cpu, 
  Settings, 
  AlertTriangle, 
  Activity,
  Database,
  Layers
} from 'lucide-react';
import { cn } from '../lib/utils';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'System Overview', icon: LayoutDashboard },
    { id: 'inventory', label: 'Ingredients', icon: Package },
    { id: 'services', label: 'Service Registry', icon: Cpu },
    { id: 'analytics', label: 'Analytics', icon: Activity },
    { id: 'database', label: 'Data Nodes', icon: Database },
  ];

  return (
    <div className="w-64 h-screen border-r border-zinc-800 bg-zinc-950 flex flex-col p-4 fixed left-0 top-0">
      <div className="flex items-center gap-3 px-2 mb-10">
        <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center">
          <Layers className="text-white w-5 h-5" />
        </div>
        <h1 className="font-bold text-xl tracking-tight">NEXUS</h1>
      </div>

      <nav className="flex-1 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all",
              activeTab === item.id 
                ? "bg-blue-600/10 text-blue-400 border border-blue-600/20" 
                : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900"
            )}
          >
            <item.icon className="w-4 h-4" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="mt-auto pt-4 border-t border-zinc-800 space-y-1">
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900">
          <Settings className="w-4 h-4" />
          Settings
        </button>
        <div className="px-3 py-4 mt-2 bg-zinc-900/50 rounded-xl border border-zinc-800">
          <div className="flex items-center gap-2 text-amber-500 mb-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span className="text-[10px] uppercase font-bold tracking-wider">System Alert</span>
          </div>
          <p className="text-[11px] text-zinc-500 leading-relaxed">
            Supplier-Webhook service is experiencing high latency (450ms).
          </p>
        </div>
      </div>
    </div>
  );
};
