import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { 
  Activity, 
  Server, 
  ShieldCheck, 
  Zap,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { stats } from '../lib/mockData';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

const data = [
  { time: '00:00', req: 4000, latency: 24 },
  { time: '04:00', req: 3000, latency: 18 },
  { time: '08:00', req: 9000, latency: 45 },
  { time: '12:00', req: 12000, latency: 32 },
  { time: '16:00', req: 15000, latency: 28 },
  { time: '20:00', req: 11000, latency: 22 },
  { time: '23:59', req: 8000, latency: 20 },
];

export const Dashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold">System Overview</h2>
          <p className="text-zinc-500 text-sm">Real-time telemetry from 1,024 polyglot nodes.</p>
        </div>
        <div className="flex gap-2">
          <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
            <span className="text-[11px] font-bold text-green-500 uppercase tracking-wider">All Systems Operational</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Services', value: stats.totalServices, icon: Server, trend: '+2', color: 'blue' },
          { label: 'Healthy Nodes', value: stats.healthyServices, icon: ShieldCheck, trend: '99.4%', color: 'green' },
          { label: 'Active Alerts', value: stats.activeAlerts, icon: Activity, trend: '-1', color: 'amber' },
          { label: 'Throughput', value: stats.throughput, icon: Zap, trend: '+12%', color: 'purple' },
        ].map((stat, i) => (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={stat.label} 
            className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl"
          >
            <div className="flex justify-between items-start mb-2">
              <div className={cn(
                "p-2 rounded-lg",
                stat.color === 'blue' && "bg-blue-500/10 text-blue-400",
                stat.color === 'green' && "bg-green-500/10 text-green-400",
                stat.color === 'amber' && "bg-amber-500/10 text-amber-400",
                stat.color === 'purple' && "bg-purple-500/10 text-purple-400",
              )}>
                <stat.icon className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-mono text-zinc-500 flex items-center gap-1">
                {stat.trend.startsWith('+') ? <ArrowUpRight className="w-3 h-3 text-green-500" /> : <ArrowDownRight className="w-3 h-3 text-red-500" />}
                {stat.trend}
              </span>
            </div>
            <div className="text-2xl font-bold font-mono">{stat.value}</div>
            <div className="text-xs text-zinc-500 uppercase tracking-wider font-semibold">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-6">Global Throughput (req/s)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorReq" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  stroke="#52525b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#52525b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                  tickFormatter={(value) => `${value / 1000}k`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px' }}
                  itemStyle={{ color: '#3b82f6' }}
                />
                <Area type="monotone" dataKey="req" stroke="#3b82f6" fillOpacity={1} fill="url(#colorReq)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <h3 className="text-sm font-bold uppercase tracking-widest text-zinc-500 mb-6">System Latency (ms)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                <XAxis 
                  dataKey="time" 
                  stroke="#52525b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <YAxis 
                  stroke="#52525b" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false} 
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px' }}
                />
                <Line type="stepAfter" dataKey="latency" stroke="#f59e0b" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
