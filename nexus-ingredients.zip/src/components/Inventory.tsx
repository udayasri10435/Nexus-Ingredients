import React from 'react';
import { Search, Filter, MoreHorizontal, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import { ingredients } from '../lib/mockData';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

export const Inventory: React.FC = () => {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold">Ingredients Inventory</h2>
          <p className="text-zinc-500 text-sm">Real-time stock levels across global warehouses.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors">
            Order Supplies
          </button>
        </div>
      </header>

      <div className="flex gap-4 items-center bg-zinc-900 p-2 rounded-xl border border-zinc-800">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <input 
            type="text" 
            placeholder="Search ingredients, batches, or suppliers..." 
            className="w-full bg-transparent border-none focus:ring-0 text-sm pl-10 py-2 text-zinc-200"
          />
        </div>
        <div className="h-6 w-px bg-zinc-800" />
        <button className="flex items-center gap-2 px-3 py-1.5 text-sm text-zinc-400 hover:text-zinc-100 transition-colors">
          <Filter className="w-4 h-4" />
          Filter
        </button>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-bottom border-zinc-800 bg-zinc-950/50">
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">Ingredient</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">Category</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">Stock Level</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">Status</th>
              <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-zinc-500">Last Sync</th>
              <th className="px-6 py-4 text-right"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800">
            {ingredients.map((item, i) => (
              <motion.tr 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                key={item.id} 
                className="hover:bg-zinc-800/30 transition-colors group"
              >
                <td className="px-6 py-4">
                  <div className="font-medium text-zinc-200">{item.name}</div>
                  <div className="text-[10px] font-mono text-zinc-500 uppercase">ID: {item.id}</div>
                </td>
                <td className="px-6 py-4">
                  <span className="px-2 py-1 bg-zinc-800 text-zinc-400 rounded text-[10px] font-bold uppercase tracking-wider">
                    {item.category}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-1.5 bg-zinc-800 rounded-full overflow-hidden max-w-[100px]">
                      <div 
                        className={cn(
                          "h-full rounded-full",
                          item.status === 'Stable' ? "bg-blue-500" : item.status === 'Low' ? "bg-amber-500" : "bg-red-500"
                        )}
                        style={{ width: `${Math.min((item.stock / 500) * 100, 100)}%` }}
                      />
                    </div>
                    <span className="font-mono text-sm text-zinc-300">{item.stock} {item.unit}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className={cn(
                    "flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider",
                    item.status === 'Stable' ? "text-green-500" : item.status === 'Low' ? "text-amber-500" : "text-red-500"
                  )}>
                    {item.status === 'Stable' ? <CheckCircle2 className="w-3.5 h-3.5" /> : item.status === 'Low' ? <Clock className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                    {item.status}
                  </div>
                </td>
                <td className="px-6 py-4 text-xs text-zinc-500 font-mono">
                  {new Date(item.lastUpdated).toLocaleTimeString()}
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="p-1 hover:bg-zinc-700 rounded transition-colors text-zinc-500 hover:text-zinc-200">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
