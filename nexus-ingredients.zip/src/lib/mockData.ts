export interface Ingredient {
  id: string;
  name: string;
  category: 'Spices' | 'Grains' | 'Oils' | 'Additives' | 'Sweeteners';
  stock: number;
  unit: string;
  status: 'Critical' | 'Low' | 'Stable';
  lastUpdated: string;
}

export interface ServiceNode {
  id: string;
  name: string;
  language: 'Java' | 'Python' | 'Go' | 'Node.js' | 'Rust' | 'C++' | 'Ruby';
  status: 'Healthy' | 'Degraded' | 'Down';
  latency: number;
  uptime: string;
}

export const ingredients: Ingredient[] = [
  { id: '1', name: 'Organic Turmeric', category: 'Spices', stock: 120, unit: 'kg', status: 'Stable', lastUpdated: '2026-03-28T08:00:00Z' },
  { id: '2', name: 'Cold-Pressed Olive Oil', category: 'Oils', stock: 45, unit: 'L', status: 'Low', lastUpdated: '2026-03-28T09:15:00Z' },
  { id: '3', name: 'Xanthan Gum', category: 'Additives', stock: 5, unit: 'kg', status: 'Critical', lastUpdated: '2026-03-28T07:30:00Z' },
  { id: '4', name: 'Brown Rice Flour', category: 'Grains', stock: 500, unit: 'kg', status: 'Stable', lastUpdated: '2026-03-28T09:45:00Z' },
  { id: '5', name: 'Stevia Extract', category: 'Sweeteners', stock: 12, unit: 'kg', status: 'Low', lastUpdated: '2026-03-28T08:20:00Z' },
];

export const services: ServiceNode[] = [
  { id: 'svc-001', name: 'Inventory-API', language: 'Go', status: 'Healthy', latency: 12, uptime: '99.99%' },
  { id: 'svc-002', name: 'Demand-Forecaster', language: 'Python', status: 'Healthy', latency: 145, uptime: '98.5%' },
  { id: 'svc-003', name: 'Auth-Gateway', language: 'Rust', status: 'Healthy', latency: 4, uptime: '100%' },
  { id: 'svc-004', name: 'Supplier-Webhook', language: 'Node.js', status: 'Degraded', latency: 450, uptime: '95.2%' },
  { id: 'svc-005', name: 'Catalog-DB-Proxy', language: 'Java', status: 'Healthy', latency: 25, uptime: '99.9%' },
  { id: 'svc-006', name: 'Quality-Control-Stream', language: 'C++', status: 'Healthy', latency: 8, uptime: '99.95%' },
];

export const stats = {
  totalServices: 1024,
  healthyServices: 1018,
  activeAlerts: 3,
  throughput: '12.4k req/s',
};
