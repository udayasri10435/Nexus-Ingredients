import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { ServiceRegistry } from './components/ServiceRegistry';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'inventory':
        return <Inventory />;
      case 'services':
        return <ServiceRegistry />;
      default:
        return (
          <div className="flex flex-col items-center justify-center h-[60vh] text-zinc-500">
            <p className="text-lg font-medium">Module under development</p>
            <p className="text-sm">The {activeTab} microservice is currently being provisioned.</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 ml-64 p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Global Status Bar */}
      <div className="fixed bottom-0 left-64 right-0 h-8 bg-zinc-900 border-t border-zinc-800 px-4 flex items-center justify-between text-[10px] font-mono text-zinc-500 z-50">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
            <span>API GATEWAY: ONLINE</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
            <span>K8S CLUSTER: ACTIVE</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span>REGION: ASIA-SOUTHEAST-1</span>
          <span>V: 2.4.0-STABLE</span>
        </div>
      </div>
    </div>
  );
}
